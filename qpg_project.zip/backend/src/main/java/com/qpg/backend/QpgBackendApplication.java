package com.qpg.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QpgBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(QpgBackendApplication.class, args);
    }
}
