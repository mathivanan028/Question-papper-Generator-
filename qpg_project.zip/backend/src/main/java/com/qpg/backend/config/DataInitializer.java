package com.qpg.backend.config;

import com.qpg.backend.model.Question;
import com.qpg.backend.repository.QuestionRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final QuestionRepository repo;

    public DataInitializer(QuestionRepository repo) { this.repo = repo; }

    @Override
    public void run(String... args) throws Exception {
        repo.save(new Question("Math", "Algebra", "Solve for x: 2x + 3 = 7", "Easy", 5));
        repo.save(new Question("Math", "Geometry", "Find area of a circle with radius r", "Medium", 7));
        repo.save(new Question("Physics", "Mechanics", "State Newton's second law", "Easy", 3));
        repo.save(new Question("Math", "Algebra", "Simplify (x^2 - 1)/(x - 1)", "Easy", 5));
        repo.save(new Question("Physics", "Optics", "Explain Snell's law", "Medium", 6));
    }
}
