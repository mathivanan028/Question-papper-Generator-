package com.qpg.backend.controller;

import com.qpg.backend.model.Question;
import com.qpg.backend.repository.QuestionRepository;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class GenerateController {

    private final QuestionRepository repo;

    public GenerateController(QuestionRepository repo) { this.repo = repo; }

    @GetMapping("/generate")
    public ResponseEntity<byte[]> generate(@RequestParam String subject,
                                           @RequestParam(defaultValue = "5") int count) throws Exception {
        List<Question> pool = repo.findBySubjectIgnoreCase(subject);
        if (pool.isEmpty()) {
            return ResponseEntity.badRequest().body(("No questions found for subject: " + subject).getBytes());
        }

        Collections.shuffle(pool);
        List<Question> selected = pool.stream().limit(count).collect(Collectors.toList());

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            doc.addPage(page);

            PDPageContentStream cs = new PDPageContentStream(doc, page);
            cs.beginText();
            cs.setFont(PDType1Font.HELVETICA_BOLD, 14);
            cs.newLineAtOffset(50, 750);
            cs.showText("Question Paper - Subject: " + subject);
            cs.setFont(PDType1Font.HELVETICA, 12);
            cs.newLineAtOffset(0, -20);
            int i = 1;
            for (Question q : selected) {
                cs.newLineAtOffset(0, -15);
                String line = i + ". (" + q.getMarks() + " marks) " + q.getQuestionText();
                cs.showText(line);
                i++;
            }
            cs.endText();
            cs.close();

            doc.save(baos);
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"question_paper.pdf\"")
                .contentType(MediaType.APPLICATION_PDF)
                .body(baos.toByteArray());
    }
}
