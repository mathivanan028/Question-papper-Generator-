package com.qpg.backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "questions")
public class Question {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String subject;
    private String topic;

    @Column(length = 2000)
    private String questionText;
    private String difficulty;
    private int marks;

    public Question() {}

    public Question(String subject, String topic, String questionText, String difficulty, int marks) {
        this.subject = subject;
        this.topic = topic;
        this.questionText = questionText;
        this.difficulty = difficulty;
        this.marks = marks;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }
    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }
    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
    public int getMarks() { return marks; }
    public void setMarks(int marks) { this.marks = marks; }
}
