package com.qpg.frontend;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class MainApp extends Application {

    private TextField subjectField;
    private TextField countField;
    private TextArea logArea;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Question Paper Generator - JavaFX");

        subjectField = new TextField();
        subjectField.setPromptText("Subject (e.g., Math)");

        countField = new TextField("5");

        Button genBtn = new Button("Generate PDF");
        genBtn.setOnAction(e -> generate());

        logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setPrefRowCount(6);

        VBox root = new VBox(10, new Label("Subject:"), subjectField, new Label("Count:"), countField, genBtn, logArea);
        root.setPadding(new Insets(10));
        stage.setScene(new Scene(root, 400, 300));
        stage.show();
    }

    private void generate() {
        String subject = subjectField.getText().trim();
        int count = Integer.parseInt(countField.getText().trim());
        try {
            HttpClient client = HttpClient.newHttpClient();
            String uri = String.format("http://localhost:8080/api/generate?subject=%s&count=%d", subject, count);
            HttpRequest req = HttpRequest.newBuilder().uri(URI.create(uri)).GET().build();
            HttpResponse<byte[]> resp = client.send(req, HttpResponse.BodyHandlers.ofByteArray());
            Path out = Path.of("generated_question_paper.pdf");
            Files.write(out, resp.body());
            logArea.appendText("PDF Generated: " + out.toAbsolutePath() + "\n");
        } catch (IOException | InterruptedException ex) {
            logArea.appendText("Error: " + ex.getMessage() + "\n");
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
